package com.example.produto;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Collectors;

public class ProdutoController {

    @FXML private TextField txtCodigo;
    @FXML private TextField txtNome;
    @FXML private TextField txtDescricao;
    @FXML private TextField txtDataFabricacao;
    @FXML private TextField txtDataValidade;
    @FXML private TextField txtPrecoCompra;
    @FXML private TextField txtPrecoVenda;
    @FXML private TextField txtQuantidadeEstoque;
    @FXML private TextField txtCategoria;

    @FXML private TableView<Produto> tableView;
    @FXML private TableColumn<Produto, String> lblCodigo;
    @FXML private TableColumn<Produto, String> lblNome;
    @FXML private TableColumn<Produto, String> lblDescricao;
    @FXML private TableColumn<Produto, String> lblDataFabricacao;
    @FXML private TableColumn<Produto, String> lblDataDeVencimento;
    @FXML private TableColumn<Produto, String> lblPrecoCompra;
    @FXML private TableColumn<Produto, String> lblPrecoVenda;
    @FXML private TableColumn<Produto, String> lblQuantidade;
    @FXML private TableColumn<Produto, String> lblCategoria;
    @FXML private Label lblMediaLucro;

    private final ObservableList<Produto> produtos = FXCollections.observableArrayList();
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @FXML
    public void initialize() {
        lblCodigo.setCellValueFactory(cell -> new SimpleStringProperty(String.valueOf(cell.getValue().getCodigo())));
        lblNome.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getNome()));
        lblDescricao.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getDescricao()));
        lblDataFabricacao.setCellValueFactory(
                cell -> new SimpleStringProperty(cell.getValue().getDataFabricacao().format(formatter))
        );
        lblDataDeVencimento.setCellValueFactory(
                cell -> new SimpleStringProperty(cell.getValue().getDataValidade().format(formatter))
        );

        lblPrecoCompra.setCellValueFactory(cell -> new SimpleStringProperty(String.valueOf(cell.getValue().getPrecoCompra())));
        lblPrecoVenda.setCellValueFactory(cell -> new SimpleStringProperty(String.valueOf(cell.getValue().getPrecoVenda())));
        lblQuantidade.setCellValueFactory(cell -> new SimpleStringProperty(String.valueOf(cell.getValue().getQuantidadeEstoque())));
        lblCategoria.setCellValueFactory(cell -> new SimpleStringProperty(cell.getValue().getCategoria()));
    }


    @FXML
    public void adicionarProduto(ActionEvent event) {
        try {
            String codigo = txtCodigo.getText();
            String nome = txtNome.getText();
            String descricao = txtDescricao.getText();
            LocalDate dataFabricacao = LocalDate.parse(txtDataFabricacao.getText(), formatter);
            LocalDate dataValidade = LocalDate.parse(txtDataValidade.getText(), formatter);
            double precoCompra = Double.parseDouble(txtPrecoCompra.getText());
            double precoVenda = Double.parseDouble(txtPrecoVenda.getText());
            int quantidade = Integer.parseInt(txtQuantidadeEstoque.getText());
            String categoria = txtCategoria.getText();

            Produto novo = new Produto(codigo, nome, descricao, dataFabricacao, dataValidade, precoCompra, precoVenda, quantidade, categoria);
            produtos.add(novo);
            tableView.setItems(produtos);

            limparCampos(); // Opcional: limpa os campos após o cadastro
        } catch (Exception e) {
            mostrarAlerta("Erro ao adicionar produto: " + e.getMessage());
        }
    }


    @FXML
    public void excluirProduto(ActionEvent event) {
        Produto selecionado = tableView.getSelectionModel().getSelectedItem();
        if (selecionado != null) {
            produtos.remove(selecionado);
        } else {
            mostrarAlerta("Selecione um produto para excluir.");
        }
    }

    @FXML
    public void consultarProduto(ActionEvent event) {
        String codigo = txtCodigo.getText();
        Optional<Produto> encontrado = produtos.stream()
                .filter(p -> p.getCodigo().equalsIgnoreCase(codigo))
                .findFirst();
        if (encontrado.isPresent()) {
            Produto p = encontrado.get();
            txtNome.setText(p.getNome());
            txtDescricao.setText(p.getDescricao());
            txtDataFabricacao.setText(String.valueOf(p.getDataFabricacao()));
            txtDataValidade.setText(String.valueOf(p.getDataValidade()));
            txtPrecoCompra.setText(String.valueOf(p.getPrecoCompra()));
            txtPrecoVenda.setText(String.valueOf(p.getPrecoVenda()));
            txtQuantidadeEstoque.setText(String.valueOf(p.getQuantidadeEstoque()));
            txtCategoria.setText(p.getCategoria());
        } else {
            mostrarAlerta("Produto não encontrado.");
        }
    }


    @FXML
    public void listarTodos(ActionEvent event) {
        tableView.setItems(produtos);
    }

    @FXML
    public void filtrarEstoqueMenorQue60(ActionEvent event) {
        tableView.setItems(produtos.filtered(p -> p.getQuantidade() < 60));

    }

    @FXML
    public void filtrarEstoqueMenorQue10(ActionEvent event) {
        tableView.setItems(produtos.filtered(p -> p.getQuantidade() < 10));

    }

    @FXML
    public void calcularMediaLucro(ActionEvent event) {
        String categoria = txtCategoria.getText();
        var media = produtos.stream()
                .filter(p -> p.getCategoria().equalsIgnoreCase(categoria))
                .mapToDouble(p -> p.getPrecoVenda() - p.getPrecoCompra())
                .average();
        lblMediaLucro.setText(String.format("Média: %.2f", media.orElse(0.0)));
    }


    @FXML
    public void listarPorCategoria(ActionEvent event) {
        String categoria = txtCategoria.getText();
        tableView.setItems(produtos.filtered(p -> p.getCategoria().equalsIgnoreCase(categoria)));

    }

    private void limparCampos() {
        txtCodigo.clear();
        txtNome.clear();
        txtDescricao.clear();
        txtDataFabricacao.clear();
        txtDataValidade.clear();
        txtPrecoCompra.clear();
        txtPrecoVenda.clear();
        txtQuantidadeEstoque.clear();
        txtCategoria.clear();
    }

    private void mostrarAlerta(String mensagem) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(null);
        alert.setContentText(mensagem);
        alert.showAndWait();
    }
}
